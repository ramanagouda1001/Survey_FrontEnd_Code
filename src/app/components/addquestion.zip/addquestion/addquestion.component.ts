import { Component, OnInit, DoCheck } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormArray, NgForm } from '@angular/forms'
import { QuestiondataService } from 'src/app/services/questiondata.service';
import { Router } from '@angular/router';
import * as XLSX from 'xlsx';
import { QuizService } from 'src/app/services/quiz.service';
import { Quiz, QuizConfig, Question, Option } from 'src/app/models';



@Component({
  selector: 'app-addquestion',
  templateUrl: './addquestion.component.html',
  styleUrls: ['./addquestion.component.css'],
   providers: [QuizService]
})
export class AddquestionComponent implements OnInit{

  
  myForm: FormGroup;
  anyquestions: {questionName: string, questionType: string, options: string[]}[];
  optionsArray: String[];
  showMainContent: Boolean = true;
  title = 'app';
  public progress: number;
  public message: string;
  public excelData: ExcelData[];
  data = [];
  

  constructor(private fb: FormBuilder, private questiondata: QuestiondataService , private router:Router) { }

  ngOnInit() {
    this.myForm = this.fb.group({
      surveyName: this.fb.control(null),
      questions: this.fb.array([
        this.returnQuestion()
      ])
    });
    console.log(this.myForm);  
   
  }
 


  returnQuestion(): FormGroup { 
    return this.fb.group({
      surveyName: this.fb.control(null),
      questionName: this.fb.control(null),
      questionType: this.fb.control(null),
      options: this.fb.array([
        this.fb.control(null)
      ])
    })
  }
 

  addQuestion() {
    (this.myForm.get('questions') as FormArray).push(this.returnQuestion());
  }

  addOption(i) {
    (((this.myForm.get('questions') as FormArray).controls[i] as FormGroup).controls.options as FormArray).push(this.fb.control(null));
  }

  removeOption(i, j) {
    (((this.myForm.get('questions') as FormArray).controls[i] as FormGroup).controls.options as FormArray).removeAt(j);
  }

  submit(form: NgForm) {
    console.log(this.myForm.value);
    this.questiondata.postQuestionData(this.myForm.value).subscribe(res => {
      console.log(res);
    })
  }

  previewQuestions() {
    this.anyquestions = this.myForm.value.questions; //array
    localStorage.setItem('anyquestions',JSON.stringify(this.myForm.value.questions));
    console.log(this.anyquestions);
    // for (let question of this.anyquestions) {
    //   for (let option of question.options) {
    //     console.log(option)   
    //   }
    // }
  }

  ShowHideButton() {
    this.showMainContent = this.showMainContent ? false : true;
 }

 
  onFileChange(evt: any) {
    //debugger
    /* wire up file reader */
    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length == 1) {
      const reader: FileReader = new FileReader();
      reader.onload = (e: any) => {
        /* read workbook */
        const bstr: string = e.target.result;
        const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });
        console.log(wb);
        /* grab first sheet */
        const wsname: string = wb.SheetNames[0];
        const ws: XLSX.WorkSheet = wb.Sheets[wsname];
        /* save data */
        this.data = <any>(XLSX.utils.sheet_to_json(ws, { header: 1 }));
      };
      reader.readAsBinaryString(target.files[0]);
    }
  }

  uploadfile() {
    let keys = this.data.shift();
    let resArr = this.data.map((e) => {
      let obj = {};
      keys.forEach((key, i) => {
        obj[key] = e[i];
      });
      return obj;
    });
    //console.log(resArr);
    //resArr.forEach(function (value) {
    //  console.log(value);
    //})
    this.excelData = resArr;
  }

}
interface ExcelData {
  [index: number]: { Id: number; Name: string; Email: string, Mobile: string };
}









